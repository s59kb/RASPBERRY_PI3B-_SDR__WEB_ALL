            
shown_center_freq = center_freq
web_port=8073
server_hostname="localhost" # If this contains an incorrect value, the web UI may freeze on load (it can't open websocket)
max_clients=10
receiver_name="[S59KB]"
receiver_location="CELJE SLOVENIJA"
receiver_qra="JN76PF"
receiver_asl=241
receiver_ant="VHF/UHV-DIAMOND X30 & HF-MULTIBAND INVERTED V"
receiver_device="RTL-MULTIBAND-SDR"
receiver_admin="kranjc.boki@gmail.com"
receiver_gps=(46.232530,15.255330)
#photo_height=350
photo_height=250
photo_title="S59KB"
photo_desc="""
Receiver is operated by: <a href="mailto:%[RX_ADMIN]">%[RX_ADMIN]</a><br/>
Device: %[RX_DEVICE]<br />
Antenna: %[RX_ANT]<br />
Website: <a href="https://www.qrz.com/lookup/s59kb" target="_blank">https://www.qrz.com/lookup/s59kb</a>
"""
sdrhu_key = ""
sdrhu_public_listing = False
fft_fps=9
fft_size=4096 
fft_voverlap_factor=0.3 
audio_compression="adpcm" 
fft_compression="adpcm" 
digimodes_enable=True 
digimodes_fft_size=1024
format_conversion="csdr convert_u8_f"
client_audio_buffer_size = 8
iq_server_port = 4951 
waterfall_colors = "[0x000000ff,0x0000ffff,0x00ffffff,0x00ff00ff,0xffff00ff,0xff0000ff,0xff00ffff,0xffffffff]"
waterfall_min_level = -90 #in dB
waterfall_max_level = -50
waterfall_auto_level_margin = (5, 40)
mathbox_waterfall_frequency_resolution = 128 
mathbox_waterfall_history_length = 10 
mathbox_waterfall_colors = "[0x000000ff,0x2e6893ff, 0x69a5d0ff, 0x214b69ff, 0x9dc4e0ff,  0xfff775ff, 0xff8a8aff, 0xb20000ff]"
csdr_dynamic_bufsize = False 
csdr_print_bufsizes = False  
csdr_through = False 
nmux_memory = 50
