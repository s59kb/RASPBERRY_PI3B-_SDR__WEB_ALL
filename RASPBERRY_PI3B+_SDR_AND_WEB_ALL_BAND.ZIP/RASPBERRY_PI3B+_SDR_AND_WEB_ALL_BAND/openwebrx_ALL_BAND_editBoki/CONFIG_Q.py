
antena_hf = 0
antena_vhf = 1
antena_uhf = 1
rezerva = 1
start_rtl_command="rtl_sdr -D2 -s {samp_rate} -f {center_freq} -p {ppm} -g {rf_gain} -".format(rf_gain=rf_gain, center_freq=center_freq, samp_rate=samp_rate, ppm=ppm)
