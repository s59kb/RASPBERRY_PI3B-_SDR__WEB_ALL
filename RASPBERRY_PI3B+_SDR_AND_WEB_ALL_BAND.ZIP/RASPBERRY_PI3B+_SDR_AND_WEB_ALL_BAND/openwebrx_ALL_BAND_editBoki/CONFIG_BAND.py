samp_rate = 2048000
center_freq = 145000000
start_freq = 144000000
start_mod = 'nfm'
rf_gain = 40
ppm = 74
start_rtl_thread=True
